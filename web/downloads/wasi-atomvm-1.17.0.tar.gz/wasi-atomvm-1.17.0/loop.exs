defmodule WASIProbe do
 def start do
IO.puts("COMPILER=1.17.0")
IO.puts("LOOP_STARTED")
loop()
 end
 def loop, do: loop()
end
