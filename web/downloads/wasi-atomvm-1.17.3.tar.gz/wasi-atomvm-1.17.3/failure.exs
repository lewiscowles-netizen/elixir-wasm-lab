defmodule WASIProbe do
 def start do
IO.puts("COMPILER=1.17.3")
:erlang.error(:intentional_wasi_failure)
 end
 def loop, do: loop()
end
